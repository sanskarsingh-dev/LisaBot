# Miss Lisa Telegram Bot

## Overview

Miss Lisa is an intelligent Telegram bot that integrates with Google Gemini AI to provide personalized conversational AI assistance. The bot features a confident, charming personality and maintains conversation context and user memories to create more engaging interactions.

## System Architecture

The application follows a modular Python architecture with clear separation of concerns:

- **Bot Layer**: Main Telegram bot implementation handling user interactions
- **AI Integration Layer**: Google Gemini AI client for generating responses  
- **Conversation Management Layer**: Context and history management for users
- **Configuration Layer**: Centralized configuration and environment management

## Key Components

### 1. Main Bot (bot.py)
- **Purpose**: Core Telegram bot implementation with command and message handlers
- **Key Features**: Enhanced personality system, memory integration, rate limiting, user interaction management
- **Design Decision**: Uses async/await pattern for non-blocking operations to handle multiple users efficiently
- **Commands**: /start, /help, /clear, /profile, /memory

### 2. Gemini Client (gemini_client.py)
- **Purpose**: Interface with Google Gemini AI API
- **Key Features**: Response generation with conversation context, configurable model parameters
- **Design Decision**: Isolated AI logic for easy testing and potential future AI provider switching
- **Model**: Uses gemini-2.5-flash with configurable temperature and token limits

### 3. Conversation Manager (conversation_manager.py)
- **Purpose**: Maintains conversation history, user profiles, and memory system per user
- **Key Features**: Message history tracking, user profile management, memory system, rate limiting, automatic cleanup
- **Design Decision**: In-memory storage with enhanced memory capabilities and configurable limits
- **Storage**: Stores up to 20 conversation entries and 50 user memories per user

### 4. Configuration (config.py)
- **Purpose**: Centralized configuration management
- **Key Features**: Bot personality system instructions, rate limiting settings, AI model configuration
- **Design Decision**: Single source of truth for all configuration to ease maintenance and deployment
- **Personality**: Defines Miss Lisa's confident, flirty, and charming personality traits

### 5. Main Entry Point (main.py)
- **Purpose**: Application bootstrap and error handling
- **Key Features**: Environment validation, logging setup, graceful error handling
- **Requirements**: TELEGRAM_BOT_TOKEN and GEMINI_API_KEY environment variables

## Data Flow

1. **User Message Reception**: Telegram sends message to bot via polling
2. **Rate Limiting Check**: Bot validates user hasn't exceeded request limits (10 requests per minute)
3. **Conversation Context Retrieval**: Previous conversation history and user profile loaded
4. **AI Processing**: Message and context sent to Gemini AI for response generation
5. **Response Delivery**: AI response sent back to user via Telegram
6. **History Update**: Conversation history updated with new exchange

## External Dependencies

### Core Dependencies
- **python-telegram-bot (v22.1+)**: Telegram Bot API wrapper for Python
- **google-genai (v1.22.0+)**: Google Gemini AI Python client
- **sift-stack-py (v0.7.0+)**: Additional utility library

### Integration Services
- **Telegram Bot API**: For receiving and sending messages
- **Google Gemini AI API**: For generating intelligent responses

## Deployment Strategy

### Environment Setup
- **Python Version**: 3.11+
- **Package Management**: Uses uv for dependency management with pyproject.toml
- **Environment Variables**: 
  - `TELEGRAM_BOT_TOKEN`: Telegram bot authentication token
  - `GEMINI_API_KEY`: Google Gemini AI API key

### Runtime Configuration
- **Logging**: Configured to output to both console and file (bot.log)
- **Error Handling**: Comprehensive error handling with graceful degradation
- **Rate Limiting**: Built-in protection against spam (10 requests per minute per user)
- **Memory Management**: Automatic cleanup of old conversations after 24 hours

### Storage Considerations
- **Current**: In-memory storage for conversations and user profiles
- **Limitation**: Data is lost on restart - suitable for development/testing
- **Future Enhancement**: Can be extended to use persistent storage (database) for production

## Changelog
- June 26, 2025: Initial setup
- June 26, 2025: Enhanced Miss Lisa's personality with more intense and seductive characteristics:
  - Updated desires to focus on making others want her through photos, voice, and fantasy
  - Added explicit fantasy about endless nights with physical intimacy
  - Enhanced secrets about when flirting is real vs playful
  - Updated preferences for smooth, tempting conversation style
  - Refined passions around creating desire, tension, and intimate moments
- June 26, 2025: Fixed response generation issues and enhanced emoji usage:
  - Increased MAX_RESPONSE_TOKENS from 150 to 800 to prevent truncation
  - Improved error handling for MAX_TOKENS responses
  - Added romantic emojis: 🍆🍑😍 to existing palette (💖💋🌶️🥵😘🔥🌙💦)
- June 28, 2025: Added automatic memory cleanup system:
  - Implemented auto cleanup for user memories when they exceed limits (50 max per user)
  - Added periodic cleanup of memories older than 7 days (runs hourly)
  - Added automatic removal of very old memories (30+ days) per user
  - Enhanced conversation manager with memory management capabilities

## User Preferences

Preferred communication style: Simple, everyday language.